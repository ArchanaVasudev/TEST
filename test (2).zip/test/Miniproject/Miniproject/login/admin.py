from django.contrib import admin
from .models import Customers
# # Register your models here.
admin.site.register(Customers)

