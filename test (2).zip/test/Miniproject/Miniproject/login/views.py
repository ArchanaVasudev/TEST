from django.contrib.auth.models import auth,User
from django.shortcuts import render,redirect
from social_django.models import UserSocialAuth
from django.contrib import messages
from login.forms import RegistrationForm
from .models import Customers
import urllib.request
import bs4 as bs
import tweepy
from textblob import TextBlob
# Create your views here.
def register(request):
    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, 'Account was created for' + username)
            return redirect('index.html')
        else:
            form = RegistrationForm()
            args = {'form': form}
            return render(request, 'register.html', args)    
    else:   
        return render(request, 'register.html')       
def home(request):
    custs=Customers.objects.all()
    return render(request,"home.html",{'custs':custs})
def index(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']

        user=auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect('home')
        else:
            messages.error(request,'invalid credentials')
            return redirect('login') 
    else:
        return render(request,"index.html")

def info(request,id):
    custids=Customers.objects.get(id=id)
    scarp_url=custids.link
    if custids.desc == "":
        source=urllib.request.urlopen(scarp_url).read()
        soup=bs.BeautifulSoup(source,'lxml')
        txt = ""
        for paragraph in soup.find_all('p'):
            block=str(paragraph.text)
            if block == None:
                pass
            else:
                txt +=(str(paragraph.text))

        custids.desc=txt
        custids.save()

    return render(request,'info.html',{"custids":custids})            



def logout(request):
    auth.logout(request)
    return render(request,"index.html")

def chat(request):
       custs=Customers.objects.all()

def chat(request):
       custs=Customers.objects.all()
       consumer_key = 'CeAY7cbO2PKL0lHuBR8j3CDfs'

       consumer_secret = '6RUXhpZgKP6H8usrxnbcqlRwJqFZglpV2P782oK3OZJM6IXCDw'

       access_token = '1253606125036945408-5zE9i6c7LTfNyqpo3CEgm98nbGpWQU'

       access_token_secret = 'bX2wcW2koRZjNZwZDVKTTlwAJfy7exCaIXxIayfETtu8R'


       auth= tweepy.OAuthHandler(consumer_key,consumer_secret)
       auth.set_access_token(access_token,access_token_secret)

       api=tweepy.API(auth)
       for names in custs:
           polarity=0
           subjectivity=0
           name=str(names.name)
           public_tweets=api.search(name)
           print(name)
           for tweet in public_tweets:
               analysis=TextBlob(tweet.text)
               Sentiment=analysis.sentiment
               polarity+=Sentiment.polarity
               subjectivity+=Sentiment.subjectivity
               names.pol=polarity
               names.sub=subjectivity
               names.save()

               return render(request,'chat.html',{'custs':custs})

