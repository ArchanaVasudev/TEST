from django.contrib import admin
from django.urls import path,include
from django.conf.urls import  url
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('login',views.index,name='index'),
    path('register',views.register,name='register'),
    # url(r'^oauth/', include('social_django.urls', namespace='social')),
     path('review',views.chat,name='chat'),
    path('home',views.home,name='home'),
    path('<id>/',views.info,name='info'),
    path('logout',views.logout,name='logout')
    
   

]