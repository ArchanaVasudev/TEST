from django.apps import AppConfig


class SocialAppConfig(AppConfig):
    name = 'social_app'
